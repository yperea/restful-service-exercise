create view v_users_roles as
  select `u`.`user_name` AS `user_name`, `r`.`role_name` AS `role_name`
  from ((`directory`.`users` `u` join `directory`.`users_roles` `ur` on ((`u`.`id` =
                                                                          `ur`.`user_id`))) join `directory`.`roles` `r` on ((
    `r`.`id` = `ur`.`role_id`)));

